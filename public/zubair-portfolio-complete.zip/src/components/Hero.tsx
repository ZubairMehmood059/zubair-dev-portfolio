import React from 'react';
import { motion } from 'motion/react';
import { usePortfolio } from '../context/PortfolioContext';
import { Magnet, ContactButton } from './common/MotionComponents';
import { FileText, Lock } from 'lucide-react';

interface HeroProps {
  onOpenAdmin?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenAdmin }) => {
  const { hero, setIsResumeModalOpen } = usePortfolio();

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative h-screen w-full flex flex-col justify-between overflow-x-clip bg-[#0C0C0C] select-none"
    >
      {/* 1. Navbar */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0, ease: [0.25, 0.1, 0.25, 1] }}
        className="w-full flex items-center justify-between px-6 md:px-10 pt-6 md:pt-8 z-30"
      >
        <button
          onClick={() => scrollTo('about')}
          className="text-[#D7E2EA] font-medium uppercase tracking-wider text-sm md:text-lg lg:text-[1.4rem] hover:opacity-70 transition-opacity duration-200 cursor-pointer focus:outline-none"
        >
          About
        </button>
        <button
          onClick={() => scrollTo('services')}
          className="text-[#D7E2EA] font-medium uppercase tracking-wider text-sm md:text-lg lg:text-[1.4rem] hover:opacity-70 transition-opacity duration-200 cursor-pointer focus:outline-none"
        >
          Services
        </button>
        <button
          onClick={() => scrollTo('projects')}
          className="text-[#D7E2EA] font-medium uppercase tracking-wider text-sm md:text-lg lg:text-[1.4rem] hover:opacity-70 transition-opacity duration-200 cursor-pointer focus:outline-none"
        >
          Projects
        </button>
        <div className="flex items-center gap-4">
          <button
            onClick={() => scrollTo('contact')}
            className="text-[#D7E2EA] font-medium uppercase tracking-wider text-sm md:text-lg lg:text-[1.4rem] hover:opacity-70 transition-opacity duration-200 cursor-pointer focus:outline-none"
          >
            Contact
          </button>
          {/* Quick utility controls for CV and Admin */}
          <button
            onClick={() => setIsResumeModalOpen(true)}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono border border-white/20 text-[#D7E2EA] hover:bg-white/10 transition-colors cursor-pointer"
            title="View Resume / CV"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>CV</span>
          </button>
          {onOpenAdmin && (
            <button
              onClick={onOpenAdmin}
              className="p-1.5 rounded-full text-white/40 hover:text-white transition-colors cursor-pointer"
              title="Admin Portal"
            >
              <Lock className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </motion.nav>

      {/* 2. Hero Heading */}
      <div className="w-full overflow-hidden text-center mt-6 sm:mt-4 md:-mt-5 z-0">
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.25, 0.1, 0.25, 1] }}
          className="hero-heading font-black uppercase tracking-tight leading-none whitespace-nowrap w-full text-[14vw] sm:text-[15vw] md:text-[16vw] lg:text-[17.5vw] select-none"
        >
          Hi, i&apos;m zubair
        </motion.h1>
      </div>

      {/* 3. Hero Portrait with Magnet component */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.6, ease: [0.25, 0.1, 0.25, 1] }}
        className="absolute left-1/2 -translate-x-1/2 z-10 w-[280px] sm:w-[360px] md:w-[440px] lg:w-[520px] top-1/2 -translate-y-1/2 sm:top-auto sm:translate-y-0 sm:bottom-0 pointer-events-auto"
      >
        <Magnet
          padding={150}
          strength={3}
          activeTransition="transform 0.3s ease-out"
          inactiveTransition="transform 0.6s ease-in-out"
          className="w-full h-auto flex justify-center"
        >
          <div className="relative w-full aspect-[3/4] max-h-[68vh] rounded-[32px] sm:rounded-[40px] overflow-hidden border border-white/10 shadow-[0_20px_60px_rgba(0,0,0,0.8)] bg-[#121212] group">
            <img
              src={hero.avatarUrl || '/images/zubair_portrait.jpg'}
              alt={hero.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
            />
            {/* Ambient vignette and subtle bottom fade */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0C0C0C] via-transparent to-transparent opacity-80 pointer-events-none" />
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-[11px] font-mono text-[#D7E2EA]/80 backdrop-blur-md bg-black/40 px-3.5 py-1.5 rounded-full border border-white/10">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Software Engineer</span>
              </span>
              <span className="text-[#BBCCD7]">SSUET • Karachi</span>
            </div>
          </div>
        </Magnet>
      </motion.div>

      {/* 4. Bottom bar */}
      <div className="w-full flex justify-between items-end px-6 md:px-10 pb-7 sm:pb-8 md:pb-10 z-20">
        {/* Left text */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.35, ease: [0.25, 0.1, 0.25, 1] }}
          className="text-[#D7E2EA] font-light uppercase tracking-wide leading-snug max-w-[160px] sm:max-w-[220px] md:max-w-[260px]"
          style={{ fontSize: 'clamp(0.75rem, 1.4vw, 1.5rem)' }}
        >
          a full-stack &amp; ai developer driven by crafting striking and unforgettable projects
        </motion.p>

        {/* Right Contact Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5, ease: [0.25, 0.1, 0.25, 1] }}
        >
          <ContactButton label="Contact Me" href="#contact" />
        </motion.div>
      </div>
    </section>
  );
};
