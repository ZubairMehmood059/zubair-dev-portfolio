import React, { useState } from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { Github, Linkedin, Mail, ArrowUp, Lock } from 'lucide-react';

interface FooterProps {
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin }) => {
  const { hero, isAdminLoggedIn } = usePortfolio();
  const [privacyModalOpen, setPrivacyModalOpen] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <footer className="bg-[#0C0C0C] border-t border-white/10 text-[#D7E2EA] font-['Kanit',sans-serif] relative">
        <div className="max-w-7xl mx-auto px-6 md:px-10 py-14">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            {/* Left Branding */}
            <div className="text-center md:text-left space-y-1.5">
              <div className="flex items-center justify-center md:justify-start gap-2.5">
                <span className="font-extrabold uppercase text-white text-xl tracking-tight">
                  {hero.name}
                </span>
                <span className="text-xs font-mono px-3 py-0.5 rounded-full bg-white/10 text-[#BBCCD7] border border-white/20">
                  Zubair.dev
                </span>
              </div>
              <p className="text-[#BBCCD7]/70 text-xs sm:text-sm font-light max-w-md">
                Full-Stack &amp; AI Developer • Sir Syed University of Engineering &amp; Technology
              </p>
            </div>

            {/* Middle Socials */}
            <div className="flex items-center gap-3">
              <a
                href={hero.socials.github}
                target="_blank"
                rel="noreferrer noopener"
                className="p-3 rounded-full border border-[#D7E2EA]/30 text-[#D7E2EA] hover:border-white hover:text-white hover:bg-white/10 transition-colors"
                aria-label="GitHub Profile"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href={hero.socials.linkedin}
                target="_blank"
                rel="noreferrer noopener"
                className="p-3 rounded-full border border-[#D7E2EA]/30 text-[#D7E2EA] hover:border-white hover:text-white hover:bg-white/10 transition-colors"
                aria-label="LinkedIn Profile"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href={`mailto:${hero.socials.email}`}
                className="p-3 rounded-full border border-[#D7E2EA]/30 text-[#D7E2EA] hover:border-white hover:text-white hover:bg-white/10 transition-colors"
                aria-label="Direct Email"
              >
                <Mail className="w-4 h-4" />
              </a>
              <button
                type="button"
                onClick={scrollToTop}
                className="p-3 rounded-full border border-[#D7E2EA]/30 text-[#D7E2EA] hover:border-white hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                title="Scroll to top"
                aria-label="Scroll to top"
              >
                <ArrowUp className="w-4 h-4" />
              </button>
            </div>

            {/* Right Meta Links */}
            <div className="flex items-center gap-5 text-xs font-mono uppercase tracking-wider text-[#BBCCD7]/70">
              <button
                type="button"
                onClick={() => setPrivacyModalOpen(true)}
                className="hover:text-white transition-colors cursor-pointer"
              >
                Privacy
              </button>

              <span className="text-white/20">•</span>

              <button
                type="button"
                onClick={onOpenAdmin}
                className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isAdminLoggedIn ? 'Admin CMS' : 'Admin'}</span>
              </button>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between text-xs font-light text-[#BBCCD7]/50 gap-2">
            <div>
              &copy; {new Date().getFullYear()} Zubair Mehmood. All rights reserved. Built with precision for production performance.
            </div>
            <div className="font-mono">
              Karachi, Pakistan (PKT, UTC+5)
            </div>
          </div>
        </div>
      </footer>

      {/* Privacy Modal */}
      {privacyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-lg bg-[#0C0C0C] border-2 border-[#D7E2EA] rounded-[32px] p-6 sm:p-8 shadow-2xl space-y-4 text-[#D7E2EA] text-xs font-['Kanit',sans-serif]">
            <h3 className="text-xl font-bold uppercase text-white tracking-tight hero-heading">
              Privacy &amp; Data Transparency
            </h3>
            <p className="font-light text-sm leading-relaxed">
              This portfolio prioritizes visitor privacy. No third-party marketing trackers, commercial pixel tags, or invasive cookies are deployed.
            </p>
            <p className="font-light text-sm leading-relaxed">
              Contact messages sent through the transmission form are delivered directly to Zubair Mehmood&apos;s authenticated administrative inbox for professional communication.
            </p>
            <div className="pt-4 flex justify-end">
              <button
                type="button"
                onClick={() => setPrivacyModalOpen(false)}
                className="px-6 py-2 rounded-full border border-white/20 text-white hover:bg-white/10 uppercase tracking-wider font-medium text-xs transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
