import React, { useState, useEffect } from 'react';
import { PortfolioProvider, usePortfolio } from './context/PortfolioContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MarqueeSection } from './components/MarqueeSection';
import { About } from './components/About';
import { ServicesSection } from './components/ServicesSection';
import { Projects } from './components/Projects';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ProjectModal } from './components/ProjectModal';
import { ResumeModal } from './components/ResumeModal';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { AdminLayout } from './components/admin/AdminLayout';
import { ToastContainer } from './components/Toast';

const PortfolioContent: React.FC = () => {
  const { isAdminLoggedIn } = usePortfolio();
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);
  const [isAdminViewOpen, setIsAdminViewOpen] = useState(false);

  // Handle hotkey to open admin modal: Alt+A or Ctrl+Shift+A
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.altKey && e.key.toLowerCase() === 'a') || (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'a')) {
        e.preventDefault();
        if (isAdminLoggedIn) {
          setIsAdminViewOpen((prev) => !prev);
        } else {
          setIsAdminLoginOpen(true);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAdminLoggedIn]);

  const handleOpenAdmin = () => {
    if (isAdminLoggedIn) {
      setIsAdminViewOpen(true);
    } else {
      setIsAdminLoginOpen(true);
    }
  };

  return (
    <div className="min-h-screen text-[#D7E2EA] font-['Kanit',sans-serif] bg-[#0C0C0C] relative antialiased transition-colors duration-500 overflow-x-clip">
      {/* Floating Navigation Header on Scroll */}
      <Navbar onOpenAdmin={handleOpenAdmin} />

      {/* Main Single-Page Sections in exact unified 3D Creator sequence */}
      <main className="relative bg-[#0C0C0C] overflow-x-clip">
        <Hero onOpenAdmin={handleOpenAdmin} />
        <MarqueeSection />
        <About />
        <ServicesSection />
        <Projects />
        <Contact />
      </main>

      {/* Footer */}
      <Footer onOpenAdmin={handleOpenAdmin} />

      {/* Interactive Modals */}
      <ProjectModal />
      <ResumeModal />

      {/* Admin Authentication & CMS Portal */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => {
          setIsAdminLoginOpen(false);
          if (sessionStorage.getItem('zubair_admin_auth') === 'true') {
            setIsAdminViewOpen(true);
          }
        }}
      />

      {isAdminLoggedIn && isAdminViewOpen && (
        <AdminLayout onClose={() => setIsAdminViewOpen(false)} />
      )}

      {/* Toast Notification Layer */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <PortfolioProvider>
      <PortfolioContent />
    </PortfolioProvider>
  );
}
